/**
 * DeepXis Music Bot - Application Error Handling
 * Standardizes user-facing error messages without exposing raw stack traces.
 */

class MusicError extends Error {
  /**
   * @param {string} userMessage Friendly message for the Discord user
   * @param {string} [internalLog] Detailed message for backend logs
   */
  constructor(userMessage, internalLog = null) {
    super(internalLog || userMessage);
    this.name = 'MusicError';
    this.userMessage = userMessage;
  }
}

const ERROR_MESSAGES = {
  NOT_IN_VOICE: "You must be connected to a voice channel to use this command.",
  DIFFERENT_VOICE: "You must be in the same voice channel as the bot.",
  CANNOT_JOIN: "I do not have permission to join your voice channel.",
  CANNOT_SPEAK: "I do not have permission to speak in your voice channel.",
  NO_PLAYER: "There is currently no active player in this server.",
  NOT_PLAYING: "This action is unavailable while nothing is playing.",
  NO_TRACK_FOUND: "Unable to find that track. Please check your search query or URL.",
  EMPTY_QUEUE: "The queue is currently empty.",
  INVALID_POSITION: "The specified queue position is invalid.",
  INVALID_VOLUME: "Volume must be a number between 0 and 100.",
  AUDIO_ERROR: "The player encountered an audio playback error.",
  SPOTIFY_ERROR: "Failed to resolve Spotify track or playlist metadata.",
  DJ_ONLY: "This command is restricted to members with the DJ role.",
  MUSIC_CHANNEL_ONLY: "Music commands are restricted to the designated music channel."
};

module.exports = {
  MusicError,
  ERROR_MESSAGES
};
