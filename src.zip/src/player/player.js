/**
 * DeepXis Music Bot - Discord Player Setup
 * Configures Discord Player instance and loads audio stream extractors.
 */

const { Player } = require('discord-player');
const { DefaultExtractors } = require('@discord-player/extractor');
let YoutubeExtractor = null;
try {
  YoutubeExtractor = require('discord-player-youtubei').YoutubeExtractor;
} catch {
  // Optional dependency: graceful fallback if container has not installed yet
}

const logger = require('../utils/logger');
const config = require('../config/config');

let player = null;

/**
 * Initialize Discord Player on the Discord client
 * @param {import('discord.js').Client} client 
 * @returns {Promise<Player>}
 */
async function initPlayer(client) {
  if (player) return player;

  player = new Player(client, {
    ytdlOptions: {
      quality: 'highestaudio',
      highWaterMark: 1 << 25
    },
    skipFFmpeg: false
  });

  // 1. Register YouTube extractor for original studio tracks & official audio (if installed)
  if (YoutubeExtractor) {
    try {
      await player.extractors.register(YoutubeExtractor, {});
      logger.info('Player', 'YouTube stream extractor loaded successfully.');
    } catch (ytErr) {
      logger.warn('Player', `Could not register YouTube extractor, using defaults: ${ytErr.message}`);
    }
  } else {
    logger.warn('Player', 'discord-player-youtubei is not installed. Using default audio extractors.');
  }

  try {
    // 2. Load default stream extractors (SoundCloud, Apple Music, Vimeo, etc.)
    await player.extractors.loadMulti(DefaultExtractors);
    logger.info('Player', 'Default stream extractors loaded successfully.');
  } catch (err) {
    logger.error('Player', 'Failed to load default extractors', err);
  }

  // Attach player event listeners
  const { registerPlayerEvents } = require('./playerEvents');
  registerPlayerEvents(player);

  return player;
}

/**
 * Get current player instance
 * @returns {Player}
 */
function getPlayer() {
  return player;
}

module.exports = {
  initPlayer,
  getPlayer
};
