/**
 * DeepXis Music Bot - Per-Guild Queue Manager
 * Prevents race conditions and duplicate players/connections.
 */

const { getPlayer } = require('./player');
const guildService = require('../services/guildService');
const config = require('../config/config');
const logger = require('../utils/logger');

const queueManager = {
  /**
   * Get an existing queue for a guild
   * @param {string} guildId 
   * @returns {import('discord-player').GuildQueue|null}
   */
  getQueue(guildId) {
    const player = getPlayer();
    if (!player) return null;
    return player.nodes.get(guildId) || null;
  },

  /**
   * Retrieve or create a voice queue for a guild
   * @param {import('discord.js').Guild} guild 
   * @param {import('discord.js').VoiceBasedChannel} voiceChannel 
   * @param {import('discord.js').TextBasedChannel} textChannel 
   * @returns {Promise<import('discord-player').GuildQueue>}
   */
  async createOrGetQueue(guild, voiceChannel, textChannel) {
    const player = getPlayer();
    if (!player) throw new Error('Player not initialized');

    let queue = player.nodes.get(guild.id);
    if (queue) {
      if (queue.metadata) {
        queue.metadata.textChannel = textChannel;
      }
      // If voice connection dropped or channel changed, reconnect safely
      if (!queue.connection || queue.channel?.id !== voiceChannel.id) {
        await queue.connect(voiceChannel);
      }
      return queue;
    }

    // Fetch guild settings from PostgreSQL / cache
    const guildSettings = await guildService.getSettings(guild.id);
    const initialVolume = guildSettings?.volume ?? config.player.defaultVolume;

    queue = player.nodes.create(guild, {
      metadata: {
        textChannel,
        guild,
        lastPanelMessage: null,
        lastStreamErrorTime: 0
      },
      volume: initialVolume,
      leaveOnEmpty: config.player.leaveOnEmpty,
      leaveOnEmptyCooldown: config.player.leaveOnEmptyCooldown,
      leaveOnEnd: config.player.leaveOnEnd,
      leaveOnEndCooldown: config.player.leaveOnEndCooldown,
      selfDeaf: true
    });

    try {
      if (!queue.connection) {
        await queue.connect(voiceChannel);
      }
      logger.info('Queue', `Created queue and connected to voice channel in guild ${guild.id}`);
    } catch (err) {
      queue.delete();
      logger.error('Queue', `Failed to connect to voice channel in guild ${guild.id}`, err);
      throw err;
    }

    return queue;
  },

  /**
   * Safely destroy a guild queue
   * @param {string} guildId 
   */
  deleteQueue(guildId) {
    const queue = this.getQueue(guildId);
    if (queue) {
      queue.delete();
      logger.info('Queue', `Deleted queue for guild ${guildId}`);
    }
  }
};

module.exports = queueManager;
