/**
 * DeepXis Music Bot - Multi-Source Query Resolver
 * Bridges Spotify Web API metadata catalog and general search with Discord Player.
 */

const { getPlayer } = require('./player');
const spotifyService = require('../services/spotifyService');
const logger = require('../utils/logger');
const { MusicError, ERROR_MESSAGES } = require('../utils/errors');

class SpotifyResolver {
  /**
   * Resolves Spotify URL (track, album, playlist) using Spotify Web API
   * and maps them to playable Discord Player tracks.
   * @param {string} url 
   * @param {import('discord.js').User} requestedBy 
   */
  static async resolve(url, requestedBy) {
    const player = getPlayer();
    const parsed = spotifyService.parseSpotifyUrl(url);
    if (!parsed.type || !parsed.id) return null;

    logger.info('Resolver', `Resolving Spotify ${parsed.type}: ${parsed.id}`);

    const hasYouTube = player.extractors.store.some(e => 
      e.identifier === 'com.retrouser955.discord-player.discord-player-youtubei'
    );
    const preferredEngine = hasYouTube ? 'youtubeSearch' : 'auto';

    if (parsed.type === 'track') {
      const meta = await spotifyService.getTrack(parsed.id);
      if (!meta) return null;

      // Search audio stream using track title and artist
      let searchResult = await player.search(meta.query, {
        requestedBy,
        searchEngine: preferredEngine
      });

      if ((!searchResult || !searchResult.hasTracks()) && preferredEngine !== 'auto') {
        searchResult = await player.search(meta.query, { requestedBy, searchEngine: 'auto' });
      }

      if (!searchResult || !searchResult.hasTracks()) {
        return null;
      }

      const track = searchResult.tracks[0];
      // Attach official Spotify metadata & artwork
      if (meta.artworkUrl) track.thumbnail = meta.artworkUrl;
      track.title = meta.title;
      track.author = meta.artist;
      track.url = meta.url;

      return {
        type: 'spotify_track',
        tracks: [track],
        playlist: null
      };
    }

    if (parsed.type === 'album') {
      const albumMeta = await spotifyService.getAlbum(parsed.id);
      if (!albumMeta || !albumMeta.tracks.length) return null;

      const tracks = [];
      for (const t of albumMeta.tracks) {
        let searchResult = await player.search(t.query, {
          requestedBy,
          searchEngine: preferredEngine
        });

        if ((!searchResult || !searchResult.hasTracks()) && preferredEngine !== 'auto') {
          searchResult = await player.search(t.query, { requestedBy, searchEngine: 'auto' });
        }

        if (searchResult && searchResult.hasTracks()) {
          const track = searchResult.tracks[0];
          if (t.artworkUrl) track.thumbnail = t.artworkUrl;
          track.title = t.title;
          track.author = t.artist;
          track.url = t.url;
          tracks.push(track);
        }
      }

      return {
        type: 'spotify_album',
        tracks,
        playlist: {
          title: albumMeta.name,
          thumbnail: albumMeta.artworkUrl,
          author: { name: albumMeta.artist }
        }
      };
    }

    if (parsed.type === 'playlist') {
      const playlistMeta = await spotifyService.getPlaylist(parsed.id);
      if (!playlistMeta || !playlistMeta.tracks.length) return null;

      const tracks = [];
      // Resolve up to 100 tracks in parallel batches to prevent blocking event loop
      const batchSize = 10;
      for (let i = 0; i < playlistMeta.tracks.length; i += batchSize) {
        const batch = playlistMeta.tracks.slice(i, i + batchSize);
        const resolvedBatch = await Promise.all(
          batch.map(async (t) => {
            try {
              let res = await player.search(t.query, { requestedBy, searchEngine: preferredEngine });
              if ((!res || !res.hasTracks()) && preferredEngine !== 'auto') {
                res = await player.search(t.query, { requestedBy, searchEngine: 'auto' });
              }
              if (res && res.hasTracks()) {
                const track = res.tracks[0];
                if (t.artworkUrl) track.thumbnail = t.artworkUrl;
                track.title = t.title;
                track.author = t.artist;
                track.url = t.url;
                return track;
              }
            } catch {
              return null;
            }
            return null;
          })
        );

        tracks.push(...resolvedBatch.filter(Boolean));
      }

      return {
        type: 'spotify_playlist',
        tracks,
        playlist: {
          title: playlistMeta.name,
          thumbnail: playlistMeta.artworkUrl,
          author: { name: playlistMeta.owner }
        }
      };
    }

    return null;
  }
}

/**
 * Prioritizes original and official studio versions over amateur remixes, slowed+reverb, and bootlegs
 * unless the user explicitly requested a remix or edit in their query.
 * @param {Array} tracks 
 * @param {string} query 
 */
function rankTracks(tracks, query) {
  if (!tracks || tracks.length <= 1) return tracks;

  // Don't re-order if query is a direct URL
  if (query.startsWith('http://') || query.startsWith('https://')) {
    return tracks;
  }

  const qLower = query.toLowerCase();
  const isSeekingRemix = /remix|slowed|reverb|sped up|nightcore|cover|karaoke|instrumental|edit|bootleg/i.test(qLower);
  if (isSeekingRemix) return tracks;

  // Filter out tracks that are clearly unwanted remixes or karaoke when user did NOT ask for one,
  // but PRESERVE YouTube's native relevance ranking for matching tracks!
  const filtered = tracks.filter(t => {
    const title = (t.title || '').toLowerCase();
    const isUnwanted = /remix|slowed\s*\+\s*reverb|slowed and reverb|sped up|nightcore|8d audio|16d audio|karaoke version|instrumental version/i.test(title);
    return !isUnwanted;
  });

  return filtered.length > 0 ? filtered : tracks;
}

class SearchResolver {
  /**
   * Resolves plain text queries or non-Spotify URLs via Discord Player
   * @param {string} query 
   * @param {import('discord.js').User} requestedBy 
   */
  static async resolve(query, requestedBy) {
    const player = getPlayer();
    const hasYouTube = player.extractors.store.some(e => 
      e.identifier === 'com.retrouser955.discord-player.discord-player-youtubei'
    );

    const primaryEngine = hasYouTube ? 'youtubeSearch' : 'auto';
    let searchResult = await player.search(query, {
      requestedBy,
      searchEngine: primaryEngine
    });

    if ((!searchResult || !searchResult.hasTracks()) && primaryEngine !== 'auto') {
      searchResult = await player.search(query, {
        requestedBy,
        searchEngine: 'auto'
      });
    }

    if (!searchResult || !searchResult.hasTracks()) {
      return null;
    }

    const rankedTracks = rankTracks(searchResult.tracks, query);

    return {
      type: searchResult.hasPlaylist() ? 'playlist' : 'track',
      tracks: rankedTracks,
      playlist: searchResult.playlist || null
    };
  }
}

/**
 * Unified resolver entry point
 * @param {string} query 
 * @param {import('discord.js').User} requestedBy 
 */
async function resolveQuery(query, requestedBy) {
  if (!query || typeof query !== 'string') {
    throw new MusicError(ERROR_MESSAGES.NO_TRACK_FOUND);
  }

  let cleanQuery = query.trim();

  // If YouTube watch URL with mix/radio list (e.g. &list=RD... or &start_radio=1), strip the radio params
  if (cleanQuery.includes('youtube.com/watch') || cleanQuery.includes('youtu.be/')) {
    if (/[?&]list=RD[^&\s]*/i.test(cleanQuery)) {
      cleanQuery = cleanQuery.replace(/[?&]list=RD[^&\s]*/gi, '').replace(/[?&]start_radio=\d+/gi, '');
      if (!cleanQuery.includes('?') && cleanQuery.includes('&')) {
        cleanQuery = cleanQuery.replace('&', '?');
      }
    }
  }

  // 1. If query is a Spotify link, route through SpotifyResolver
  const isSpotify = spotifyService.parseSpotifyUrl(cleanQuery).type !== null;
  if (isSpotify && spotifyService.isAvailable()) {
    try {
      const spotifyResult = await SpotifyResolver.resolve(cleanQuery, requestedBy);
      if (spotifyResult && spotifyResult.tracks.length > 0) {
        return spotifyResult;
      }
    } catch (err) {
      logger.warn('Resolver', `Spotify resolution encountered an issue, falling back to direct search: ${err.message}`);
    }
  }

  // 2. Route through SearchResolver
  const result = await SearchResolver.resolve(cleanQuery, requestedBy);
  if (!result || !result.tracks.length) {
    throw new MusicError(ERROR_MESSAGES.NO_TRACK_FOUND);
  }

  return result;
}

module.exports = {
  resolveQuery,
  SpotifyResolver,
  SearchResolver
};
