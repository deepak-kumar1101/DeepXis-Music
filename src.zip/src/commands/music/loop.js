/**
 * DeepXis Music Bot - /loop Command
 */

const { SlashCommandBuilder } = require('discord.js');
const { QueueRepeatMode } = require('discord-player');
const { validateVoice, validatePlayer } = require('../../utils/validators');
const queueManager = require('../../player/queue');
const { enforceDJ, enforceMusicChannel } = require('../../config/permissions');
const { createSuccessEmbed } = require('../../ui/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('loop')
    .setDescription('Set playback loop mode')
    .addStringOption(opt =>
      opt.setName('mode')
        .setDescription('Loop mode')
        .setRequired(true)
        .addChoices(
          { name: 'Off', value: 'off' },
          { name: 'Track', value: 'track' },
          { name: 'Queue', value: 'queue' },
          { name: 'Autoplay', value: 'autoplay' }
        )
    ),

  category: 'music',

  async execute(interaction) {
    await enforceMusicChannel(interaction);
    validateVoice(interaction, true);
    await enforceDJ(interaction.member, interaction.guildId);

    const queue = validatePlayer(queueManager.getQueue(interaction.guildId));
    const mode = interaction.options.getString('mode', true);

    let repeatMode = QueueRepeatMode.OFF;
    let modeText = 'Off';

    switch (mode) {
      case 'track':
        repeatMode = QueueRepeatMode.TRACK;
        modeText = 'Track (repeating current track)';
        break;
      case 'queue':
        repeatMode = QueueRepeatMode.QUEUE;
        modeText = 'Queue (repeating entire queue)';
        break;
      case 'autoplay':
        repeatMode = QueueRepeatMode.AUTOPLAY;
        modeText = 'Autoplay (continuous recommendations)';
        break;
      default:
        repeatMode = QueueRepeatMode.OFF;
        modeText = 'Off';
        break;
    }

    queue.setRepeatMode(repeatMode);

    return interaction.reply({
      embeds: [createSuccessEmbed(`Loop mode set to: **${modeText}**`)]
    });
  }
};
